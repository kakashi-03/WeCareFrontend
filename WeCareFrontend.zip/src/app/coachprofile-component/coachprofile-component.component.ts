import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coachprofile-component',
  templateUrl: './coachprofile-component.component.html',
  styleUrls: ['./coachprofile-component.component.css']
})
export class CoachprofileComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
