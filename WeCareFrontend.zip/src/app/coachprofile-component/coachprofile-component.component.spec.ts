import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoachprofileComponentComponent } from './coachprofile-component.component';

describe('CoachprofileComponentComponent', () => {
  let component: CoachprofileComponentComponent;
  let fixture: ComponentFixture<CoachprofileComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoachprofileComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoachprofileComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
